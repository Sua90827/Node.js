const memberList = [
    {id:"aaa", name:"홍길동", addr:"산골짜기"},
    {id:"bbb", name:"김개똥", addr:"개똥별"},
    {id:"ccc", name:"고길동", addr:"마포구"},
];
module.exports = memberList;
    