const express = require("express");
const ctrl = require("../controller/common_controller01");
const router = express.Router();
router.get("/", ctrl.index );
module.exports = router;
