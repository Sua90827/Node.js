const express = require("express");
const commonRouter = require("./src/routes/common_router01");
const app = express();
app.set("views","./src/views");
app.set("view engine", "ejs");

app.use("/", commonRouter);

const memberRouter = require("./src/routes/member/member_router");
app.use("/member/", memberRouter);


app.listen(3000, ()=>{console.log("3000 서버 연결")} );
